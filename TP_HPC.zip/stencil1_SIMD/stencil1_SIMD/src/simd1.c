/* --------------- */
/* --- simd1.c --- */
/* --------------- */

#include <stdio.h>
#include <stdlib.h>

#include "nrdef.h"
#include "nrutil.h"

#include "vnrdef.h"
#include "vnrutil.h"

#include "mutil.h"

#include "mymacro.h"
#include "simd_macro.h"
#include "simd1.h"

// ------------------
void test_macro(void)
// ------------------
{
    vfloat32 a, b, c, d, e;
    vfloat32 au, cu; // unaligned vector
    vfloat32 a3, a5; // add3 add5
    puts("------------------");
    puts("--- test_macro ---");
    puts("------------------");
    puts("");

    puts("vec_left et vec_right");

    // setr simule le fonctionnement d'un load avec permutation des blocs grace au "r" = reverse
    a = _mm_setr_ps(1,   2,  3,  4);
    b = _mm_setr_ps(5,   6,  7,  8);
    c = _mm_setr_ps(9,  10, 11, 12);
    d = _mm_setr_ps(13, 14, 15, 16);
    e = _mm_setr_ps(17, 18, 19, 20);

    display_vfloat32(a, "%4.0f", "a ");
    puts("");
    display_vfloat32(b, "%4.0f", "b ");
    puts("");
    display_vfloat32(c, "%4.0f", "c ");
    puts("\n");

    au = vec_left1(a, b);
    cu = vec_right1(b, c);
    display_vfloat32(au, "%4.0f", "au");
    puts("");
    display_vfloat32(cu, "%4.0f", "cu");
    puts("\n");

    puts("vec_add3 et vec_add5");
    a3 = vec_add3(a, b, c);
    a5 = vec_add5(a, b, c, d, e);

    display_vfloat32(a3, "%4.0f", "a3");
    puts("");
    display_vfloat32(a5, "%4.0f", "a5");
    puts("\n");
}
// -------------------------------------------------------------------
void add_vf32vector(vfloat32 *vX1, vfloat32 *vX2, int n, vfloat32 *vY)
// -------------------------------------------------------------------
{
    vfloat32 x1, x2, y;

    for(int i=0; i<n; i++)
    {

        x1 = _mm_load_ps((float32*) &vX1[i]);
        x2 = _mm_load_ps((float32*) &vX2[i]);

        y = _mm_add_ps(x1, x2);

        DEBUG(display_vfloat32(x1, "%4.0f", "x1 ="));
        DEBUG(puts(""));
        DEBUG(display_vfloat32(x2, "%4.0f", "x2 ="));
        DEBUG(puts(""));
        DEBUG(display_vfloat32(y,  "%4.0f", "y  ="));
        DEBUG(puts(""));

        _mm_store_ps((float*) &vY[i], y);

        DEBUG(puts("-------------------"));
    }
}
// ---------------------------------------------------------
vfloat32 dot_vf32vector(vfloat32 *vX1, vfloat32 *vX2, int n)
// ---------------------------------------------------------
{
    vfloat32 z;
    vfloat32 x1, x2, p, s;
    s = _mm_set_ps(0,0,0,0);

    for(int i=0; i<n; i++)
    {
        x1 = _mm_load_ps((float32*) &vX1[i]);
        x2 = _mm_load_ps((float32*) &vX2[i]);

        p = _mm_mul_ps(x1, x2); //Resultat du produit

        DEBUG(display_vfloat32(x1, "%4.0f", "x1 ="));
        DEBUG(puts(""));
        DEBUG(display_vfloat32(x2, "%4.0f", "x2 ="));
        DEBUG(puts(""));
        DEBUG(display_vfloat32(p,  "%4.0f", "p  ="));
        DEBUG(puts(""));

        s = _mm_add_ps(s, p);
        DEBUG(display_vfloat32(s,  "%4.0f", "s  ="));
        DEBUG(puts(""));
    }
    x1 = _mm_shuffle_ps(s, s, _MM_SHUFFLE(2,1,0,3));
    x2 = _mm_add_ps(x1, s);

    x1 = _mm_shuffle_ps(x2, x2, _MM_SHUFFLE(1,0,3,2));
    s = _mm_add_ps(x1, x2);




    return s; // attention il faut retourner un registre SIMD et non un scalaire

}
// ----------------------------------------------------
void sum3_vf32vector(vfloat32 *vX, int n, vfloat32 *vY)
// ----------------------------------------------------
{

//Au debut
//      0 1 2 3       0 1 2 3        0 1 2 3
// A = [0 0 0 0] B = [1 2 3 4 ] C = [5 6 7 8]
//Xim1 = [0 1 2 3] Xi = B = [1 2 3 4 ] ; Xip1 = [2 3 4 5 ]
//Yi = Xim1 + Xi + Xip1
    int i = 0;
    vfloat32 Xim1, Xip1, res;
    vfloat32 A, B, C; // B = Xi
    vfloat tmp1;

    A = _mm_load_ps((float32*) &vX[i-1]);
    B = _mm_load_ps((float32*) &vX[i]);

    for(i = 0; i < n; i++)
    {
        C = _mm_load_ps((float32*) &vX[i+1]);
        tmp1 = _mm_shuffle_ps(A, B, _MM_SHUFFLE(0, 0, 3, 3));
        Xim1 = _mm_shuffle_ps(tmp1, B, _MM_SHUFFLE(2, 1, 2, 0));

        tmp1 = _mm_shuffle_ps(B, C, _MM_SHUFFLE(0, 0, 3, 3));
        Xip1 = _mm_shuffle_ps(B, tmp1, _MM_SHUFFLE(2, 0, 2, 1));

        res = _mm_add_ps(Xim1,B);
        res = _mm_add_ps(res, Xip1);
        _mm_store_ps((float*) &vY[i], res);

        A = B;//Rotation
        B = C;

    }

}
// ----------------------------------------------------
void sum5_vf32vector(vfloat32 *vX, int n, vfloat32 *vY)
// ----------------------------------------------------
{
	//Au debut
//      0 1 2 3       0 1 2 3        0 1 2 3
// A = [0 0 0 0] B = [1 2 3 4 ] C = [5 6 7 8]
//Xim2 = [0 0 1 2] Xim1 = [0 1 2 3]; Xi = B = [1 2 3 4 ] ; Xip1 = [2 3 4 5 ] Xip2 = [3 4 5 6]
//Yi = Xim1 + Xi + Xip1
    int i = 0;
    vfloat32 Xim1, Xim2, Xip1, Xip2, res;
    vfloat32 A, B, C; // B = Xi
    vfloat tmp1;
	for(i = 0; i < n; i++)
    {
	    A = _mm_load_ps((float32*) &vX[i-1]);
	    B = _mm_load_ps((float32*) &vX[i]);

	    C = _mm_load_ps((float32*) &vX[i+1]);
	    tmp1 = _mm_shuffle_ps(A, B, _MM_SHUFFLE(0, 0, 3, 3));
	    Xim1 = _mm_shuffle_ps(tmp1, B, _MM_SHUFFLE(2, 1, 2, 0));

	    tmp1 = _mm_shuffle_ps(B, C, _MM_SHUFFLE(0, 0, 3, 3));
	    Xip1 = _mm_shuffle_ps(B, tmp1, _MM_SHUFFLE(2, 0, 2, 1));

		res = _mm_add_ps(Xim1,B);
	    res = _mm_add_ps(res, Xip1);

	    Xim2 = _mm_shuffle_ps(A, B, _MM_SHUFFLE(1, 0, 3, 2));
	    res = _mm_add_ps(res, Xim2);


	    Xip2 = _mm_shuffle_ps(B, C, _MM_SHUFFLE(1, 0, 3, 2));
	    res = _mm_add_ps(res, Xip2);

  	    _mm_store_ps((float*) &vY[i], res);


	    A = B;//Rotation
	    B = C;
	}
}
// ----------------------------------------------------
void min3_vf32vector(vfloat32 *vX, int n, vfloat32 *vY)
// ----------------------------------------------------
{
	//Au debut
//      0 1 2 3       0 1 2 3        0 1 2 3
// A = [0 0 0 0] B = [1 2 3 4 ] C = [5 6 7 8]
//Xim1 = [0 1 2 3] Xi = B = [1 2 3 4 ] ; Xip1 = [2 3 4 5 ]
//Yi = Xim1 + Xi + Xip1
    int i = 0;
    vfloat32 Xim1, Xip1, res;
    vfloat32 A, B, C; // B = Xi
    vfloat tmp1;

    A = _mm_load_ps((float32*) &vX[i-1]);
    B = _mm_load_ps((float32*) &vX[i]);

    for(i = 0; i < n; i++)
    {
        C = _mm_load_ps((float32*) &vX[i+1]);
        tmp1 = _mm_shuffle_ps(A, B, _MM_SHUFFLE(0, 0, 3, 3));
        Xim1 = _mm_shuffle_ps(tmp1, B, _MM_SHUFFLE(2, 1, 2, 0));

        tmp1 = _mm_shuffle_ps(B, C, _MM_SHUFFLE(0, 0, 3, 3));
        Xip1 = _mm_shuffle_ps(B, tmp1, _MM_SHUFFLE(2, 0, 2, 1));

        res = _mm_min_ps(Xim1,B);
        res = _mm_min_ps(res, Xip1);
        _mm_store_ps((float*) &vY[i], res);

        A = B;//Rotation
        B = C;

    }

}
// ----------------------------------------------------
void min5_vf32vector(vfloat32 *vX, int n, vfloat32 *vY)
// ----------------------------------------------------
{
	//Au debut
//      0 1 2 3       0 1 2 3        0 1 2 3
// A = [0 0 0 0] B = [1 2 3 4 ] C = [5 6 7 8]
//Xim2 = [0 0 1 2] Xim1 = [0 1 2 3]; Xi = B = [1 2 3 4 ] ; Xip1 = [2 3 4 5 ] Xip2 = [3 4 5 6]
//Yi = Xim1 + Xi + Xip1
    int i = 0;
    vfloat32 Xim1, Xim2, Xip1, Xip2, res;
    vfloat32 A, B, C; // B = Xi
    vfloat tmp1;
	for(i = 0; i < n; i++)
    {
	    A = _mm_load_ps((float32*) &vX[i-1]);
	    B = _mm_load_ps((float32*) &vX[i]);

	    C = _mm_load_ps((float32*) &vX[i+1]);
	    tmp1 = _mm_shuffle_ps(A, B, _MM_SHUFFLE(0, 0, 3, 3));
	    Xim1 = _mm_shuffle_ps(tmp1, B, _MM_SHUFFLE(2, 1, 2, 0));

	    tmp1 = _mm_shuffle_ps(B, C, _MM_SHUFFLE(0, 0, 3, 3));
	    Xip1 = _mm_shuffle_ps(B, tmp1, _MM_SHUFFLE(2, 0, 2, 1));

		res = _mm_min_ps(Xim1,B);
	    res = _mm_min_ps(res, Xip1);

	    Xim2 = _mm_shuffle_ps(A, B, _MM_SHUFFLE(1, 0, 3, 2));
	    res = _mm_min_ps(res, Xim2);


	    Xip2 = _mm_shuffle_ps(B, C, _MM_SHUFFLE(1, 0, 3, 2));
	    res = _mm_min_ps(res, Xip2);

  	    _mm_store_ps((float*) &vY[i], res);


	    A = B;//Rotation
	    B = C;
	}
}
// -------------------------------------------------------------
void positive_add3_vf32vector(vfloat32 *vX, int n, vfloat32 *vY)
// -------------------------------------------------------------
{
	vfloat32 x1, y1;
    vfloat32 cX, dX;
    vfloat zero = _mm_set_ps(0,0,0,0);
    y1 = _mm_set_ps(0, 0, 0, 0);
    //d = _mm_or_ps(_mm_and_ps(c,b), _mm_andnot_ps(c,a));

    for(int i=0; i<n; i++)
    {

        x1 = _mm_load_ps((float32*) &vX[i]);

        cX = _mm_cmplt_ps(x1, zero);//Verifie si X1 est inferieur a 0
        dX = _mm_or_ps(_mm_and_ps(cX,zero), _mm_andnot_ps(cX, x1));//Si c'est inferieur a 0, on met 0 sinon on met x1

        y1 = _mm_add_ps(dX, y1); //LLa valeur est ajoutee si c'est positive sinon ca rajoute 0

        /*DEBUG(display_vfloat32(x1, "%4.0f", "x1 ="));DEBUG(puts(""));
        DEBUG(display_vfloat32(dX, "%4.0f", "dx1 ="));DEBUG(puts(""));
        DEBUG(display_vfloat32(y1,  "%4.0f", "y1  ="));DEBUG(puts(""));*/

        _mm_store_ps((float*) &vY[i], y1);

    }

}
// -------------------------------------------------------------
void positive_avg3_vf32vector(vfloat32 *vX, int n, vfloat32 *vY)
// -------------------------------------------------------------
{
	vfloat32 x1, y1;
    vfloat32 cX, dX;
    vfloat zero = _mm_set_ps(0,0,0,0);
    vfloat un = _mm_set_ps(1,1,1,1); //Pour diviser par 1

    y1 = _mm_set_ps(0, 0, 0, 0);
    vfloat32 res;
    //d = _mm_or_ps(_mm_and_ps(c,b), _mm_andnot_ps(c,a));


    vfloat32 nbSup0 = _mm_set1_ps(0.0f);
    vfloat32 tmpcX;
    for(int i=0; i<n; i++)
    {

        x1 = _mm_load_ps((float32*) &vX[i]);

        cX = _mm_cmple_ps(x1, zero);//Verifie si X1 est inferieur a 0
        dX = _mm_or_ps(_mm_and_ps(cX,zero), _mm_andnot_ps(cX, x1));//Si c'est inferieur a 0, on met 0 sinon on met x1

        y1 = _mm_add_ps(dX, y1); //La valeur est ajoutee si c'est positive sinon ca rajoute 0

/*
        DEBUG(display_vfloat32(x1, "%4.0f", "x1 ="));DEBUG(puts(""));
        DEBUG(display_vfloat32(dX, "%4.0f", "dx1 ="));DEBUG(puts(""));
        DEBUG(display_vfloat32(y1,  "%4.0f", "y1  ="));DEBUG(puts(""));*/

        tmpcX = _mm_andnot_ps(cX, un);//On a 0 quand x est superieur a 0 donc j'inverse pour avoir un 1 et faire +1 pour avoir le total
        nbSup0 = _mm_add_ps(nbSup0, tmpcX);//Total positif
		cX = _mm_cmple_ps(nbSup0, zero);//Verifie si X1 est inferieur ou egal a 0
        dX = _mm_or_ps(_mm_and_ps(cX,un), _mm_andnot_ps(cX, nbSup0));//Si c'est inferieur a 0, on met 0 sinon on met x1
        res = _mm_div_ps(y1, dX);
        _mm_store_ps((float*) &vY[i], res);

    }
}
// --------------------------------------------------
vfloat32 positive_avg_vf32vector(vfloat32 *vX, int n)
// --------------------------------------------------
{
    vfloat32 avg3 = _mm_set1_ps(0.0f);

    vfloat32 x1, y1;
    vfloat32 cX, dX;
    vfloat zero = _mm_set_ps(0,0,0,0);
    vfloat un = _mm_set_ps(1,1,1,1); //Pour diviser par 1

    y1 = _mm_set_ps(0, 0, 0, 0);
    vfloat32 res;
    //d = _mm_or_ps(_mm_and_ps(c,b), _mm_andnot_ps(c,a));


    vfloat32 nbSup0 = _mm_set1_ps(0.0f);
    vfloat32 tmpcX;
    for(int i=0; i<n; i++)
    {

        x1 = _mm_load_ps((float32*) &vX[i]);

        cX = _mm_cmple_ps(x1, zero);//Verifie si X1 est inferieur a 0
        dX = _mm_or_ps(_mm_and_ps(cX,zero), _mm_andnot_ps(cX, x1));//Si c'est inferieur a 0, on met 0 sinon on met x1

        y1 = _mm_add_ps(dX, y1); //La valeur est ajoutee si c'est positive sinon ca rajoute 0


       /* DEBUG(display_vfloat32(x1, "%4.0f", "x1 ="));DEBUG(puts(""));
        DEBUG(display_vfloat32(dX, "%4.0f", "dx1 ="));DEBUG(puts(""));
        DEBUG(display_vfloat32(y1,  "%4.0f", "y1  ="));DEBUG(puts(""));*/

        tmpcX = _mm_andnot_ps(cX, un);//On a 0 quand x est superieur a 0 donc j'inverse pour avoir un 1 et faire +1 pour avoir le total
        nbSup0 = _mm_add_ps(nbSup0, tmpcX);//Total positif
		
    }
    cX = _mm_cmple_ps(nbSup0, zero);//Verifie si X1 est inferieur ou egal a 0
    dX = _mm_or_ps(_mm_and_ps(cX,un), _mm_andnot_ps(cX, nbSup0));//Si c'est nul, on met 1  sinon on met le nombre d'additions faites
    avg3 = _mm_div_ps(y1, dX);

    return avg3;

}

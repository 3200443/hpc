#include <stdio.h>
#include <omp.h>

int main(){
	omp_set_num_threads(7);
	#pragma omp parallel 
	printf("Hello\n");
	printf("Hello\n");
	printf("World\n");

	return 0;
}
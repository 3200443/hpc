#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <pthread.h>
#define TAILLE 128




char buffer0[TAILLE];
char buffer1[TAILLE];
pthread_mutex_t mutexBuffer1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutexBuffer0 = PTHREAD_MUTEX_INITIALIZER;
int lockbuf1 = 1;
int lockbuf0 = 1;

//Avec mutex => Fonctionnel

/*
void f0()
{
    int i;
    for(i = 0; i < 10; i++)
    {
        buffer0[i] = (rand()%26) +'a';
    }
    buffer0[i] = '\0';
    pthread_mutex_unlock(&mutexBuffer0);

    pthread_mutex_lock(&mutexBuffer1);
    printf("Buffer1 = %s\n",buffer1);
    pthread_mutex_unlock(&mutexBuffer1);

}

void* f1(void* arg)
{

    int i;

    for(i = 0; i < 10; i++)
    {
        buffer1[i] = (rand()%26) + 'A';
    }
    buffer1[i] = '\0';
    pthread_mutex_unlock(&mutexBuffer1);


    pthread_mutex_lock(&mutexBuffer0);
    printf("Buffer0 = %s\n",buffer0);
    pthread_mutex_unlock(&mutexBuffer0);

    pthread_exit(NULL);

}

*/
void f0()
{
    int i;

    for(i = 0; i < 10; i++)
    {
        buffer0[i] = (rand()%26) +'a';
    }
    buffer0[i] = '\0';

    lockbuf0 = 0;
    while(lockbuf1 == 1);
    printf("Buffer1 = %s\n",buffer1);

}

void* f1(void* arg)
{

    int i;

    for(i = 0; i < 10; i++)
    {
        buffer1[i] = (rand()%26) + 'A';
    }
    buffer1[i] = '\0';

    lockbuf1 = 0;
    while(lockbuf0 == 1);
    printf("Buffer0 = %s\n",buffer0);

    pthread_exit(NULL);

}



int main()
{
    srand(time(NULL));
    pthread_t thread1;
    pthread_mutex_lock(&mutexBuffer0);
    pthread_mutex_lock(&mutexBuffer1);

    if(pthread_create(&thread1, NULL, f1, NULL) == -1)
    {
        printf("Erreur thread f0\n");
        exit(1);
    }
    f0();


    pthread_join(thread1, NULL);

    return 0;

}

/* ---------------- */
/* --- matrix.c --- */
/* ---------------- */

#include <math.h>

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>

#include "nrdef.h"
#include "nrutil.h"

// ---------------------------------------------------
void dup_f32matrix_ij(float32 **A, float32 **B, int n)
// ---------------------------------------------------
{
    int i, j;
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {
            B[i][j] = A[i][j];
        }
    }
}
// ---------------------------------------------------
void dup_f32matrix_ji(float32 **A, float32 **B, int n)
// ---------------------------------------------------
{
    int i, j;
    for(j = 0; j < n; j++)
    {
        for(i = 0; i < n; i++)
        {
            B[i][j] = A[i][j];
        }
    }
}
// ---------------------------------------------------
void trn_f32matrix_ij(float32 **A, float32 **B, int n)
// ---------------------------------------------------
{
    // la double boucle parcours l'espace d'arrivee en ij
}
// ---------------------------------------------------
void trn_f32matrix_ji(float32 **A, float32 **B, int n)
// ---------------------------------------------------
{
    // la double boucle parcours l'espace d'arrivee en ji
}
// ----------------------------------------------------------------
void add_f32matrix_ij(float32 **A, float32 **B, float32 **C, int n)
// ----------------------------------------------------------------
{
    int i, j;
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {
            C[i][j]= B[i][j] + A[i][j];
        }
    }

}
// ----------------------------------------------------------------
void add_f32matrix_ji(float32 **A, float32 **B, float32 **C, int n)
// ----------------------------------------------------------------
{
    int i, j;
    for(j = 0; j < n; j++)
    {
        for(i = 0; i < n; i++)
        {
            C[i][j]= B[i][j] + A[i][j];
        }
    }
}
// --------------------------------------------------------
void accumulate_f32matrix_h(float32 **A, float32 *B, int n)
// --------------------------------------------------------
{
    int i, j;
    float32 temp = 0;
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {
            temp += A[i][j];
        }
        B[i] = temp;
        temp = 0;
    }
}
// --------------------------------------------------------
void accumulate_f32matrix_v(float32 **A, float32 *B, int n)
// --------------------------------------------------------
{
    int i, j;
    float32 temp = 0;
    for(j = 0; j < n; j++)
    {
        for(i = 0; i < n; i++)
        {
            temp += A[i][j];
        }
        B[i] = temp;
        temp = 0;
    }
}
// ---------------------------------------------------------
void accumulate_f32matrix_vh(float32 **A, float32 *B, int n)
// ---------------------------------------------------------
{
}

// -----------------------------------------------------------------
void mul_f32matrix_ijk(float32 **A, float32 **B, float32 **C, int n)
// -----------------------------------------------------------------
{
    int i,j,k;
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {
            for(k = 0; k < n; k++)
            {
                C[i][j] += A[i][k]*B[k][j];
            }
        }
    }
}

// -----------------------------------------------------------------
void mul_f32matrix_ikj(float32 **A, float32 **B, float32 **C, int n)
// -----------------------------------------------------------------
{
    int i,j,k;
    for(i = 0; i < n; i++)
    {
        for(k = 0; k < n; k++)
        {
            for(j = 0; j < n; j++)
            {
                C[i][j] += A[i][k]*B[k][j];
            }
        }
    }
}
// -----------------------------------------------------------------
void mul_f32matrix_jik(float32 **A, float32 **B, float32 **C, int n)
// -----------------------------------------------------------------
{
    int i,j,k;
    for(j = 0; j < n; j++)
    {
        for(i = 0; i < n; i++)
        {
            for(k = 0; k < n; k++)
            {
                C[i][j] += A[i][k]*B[k][j];
            }
        }
    }
}
// -----------------------------------------------------------------
void mul_f32matrix_jki(float32 **A, float32 **B, float32 **C, int n)
// -----------------------------------------------------------------
{
    int i,j,k;
    for(j = 0; j < n; j++)
    {
        for(k = 0; k < n; k++)
        {
            for(i = 0; i < n; i++)
            {
                C[i][j] += A[i][k]*B[k][j];
            }
        }
    }
}
// -----------------------------------------------------------------
void mul_f32matrix_kij(float32 **A, float32 **B, float32 **C, int n)
// -----------------------------------------------------------------
{
    int i,j,k;
    for(k = 0; k < n; k++)
    {
        for(i = 0; i < n; i++)
        {
            for(j = 0; j < n; j++)
            {
                C[i][j] += A[i][k]*B[k][j];
            }
        }
    }
}
// -----------------------------------------------------------------
void mul_f32matrix_kji(float32 **A, float32 **B, float32 **C, int n)
// -----------------------------------------------------------------
{
    int i,j,k;
    for(k = 0; k < n; k++)
    {
        for(j = 0; j < n; j++)
        {
            for(i = 0; i < n; i++)
            {
                C[i][j] += A[i][k]*B[k][j];
            }
        }
    }
}
// ------------------------------------------------------
void sum3_f32matrix_loop(float32 **X, float32 **Y, int n)
/* --------------------------------------------------- */
{
    int i, j, deti, detj;
    //Sans Loop unwinding
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {
            Y[i][j] = 0;
            for(deti = -1; deti <= 1; deti++)
            {
                for(detj = -1; detj <= 1; detj++)
                {
                    Y[i][j] += X[i+deti][j+detj];
                }
            }
        }
    }
    //Avec Loop Unwinding

}
// -------------------------------------------------------
void sum3_f32matrix_array(float32 **X, float32 **Y, int n)
// -------------------------------------------------------
{
    int i, j;
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {
            Y[i][j] = 0;
            Y[i][j]+=X[i-1][j-1];
            Y[i][j]+=X[i-1][j];
            Y[i][j]+=X[i-1][j+1];

            Y[i][j]+=X[i][j-1];
            Y[i][j]+=X[i][j];
            Y[i][j]+=X[i][j+1];

            Y[i][j]+=X[i+1][j-1];
            Y[i][j]+=X[i+1][j];
            Y[i][j]+=X[i+1][j+1];


        }
    }
}
// -----------------------------------------------------
void sum3_f32matrix_reg(float32 **X, float32 **Y, int n)
// -----------------------------------------------------
{
    /* m = moins, p = plus
    Xim1jm1 = x[i-1][j-1]
    Xim1j=X[i-1][j];
    Xim1jp1=X[i-1][j+1];

    Xijm1=X[i][j-1];
    Xij=X[i][j];
    Xijp1=X[i][j+1];

    Xip1jm1=X[i+1][j-1];
    Xip1j=X[i+1][j];
    Xip1jp1=X[i+1][j+1];
    */
    int i, j;
    float32 YTemp = 0;
    float32 Xim1jm1, Xim1j, Xim1jp1;

    float32 Xijm1, Xij, Xijp1;

    float32 Xip1jm1, Xip1j, Xip1jp1;

    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {
            //Loads
            Xim1jm1 = X[i-1][j-1];
            Xim1j=X[i-1][j];
            Xim1jp1=X[i-1][j+1];

            Xijm1=X[i][j-1];
            Xij=X[i][j];
            Xijp1=X[i][j+1];

            Xip1jm1=X[i+1][j-1];
            Xip1j=X[i+1][j];
            Xip1jp1=X[i+1][j+1];


            YTemp = Xim1jm1 + Xim1j + Xim1jp1 + Xijm1 + Xij + Xijp1 +
                    Xip1jm1 + Xip1j + Xip1jp1 ;//Calculs

            Y[i][j] = YTemp;// store
            YTemp = 0;
        }
    }
}

// -----------------------------------------------------
void sum3_f32matrix_rot(float32 **X, float32 **Y, int n)
// -----------------------------------------------------
{

    int i = 0, j = 0;
    float32 YTemp = 0;
    float32 Xim1jm1, Xim1j, Xim1jp1;

    float32 Xijm1, Xij, Xijp1;

    float32 Xip1jm1, Xip1j, Xip1jp1;

    //Loads - prologue


    for(i = 0; i < n; i++)
    {
        Xim1jm1 = X[i-1][j-1];
        Xijm1=X[i][j-1];
        Xip1jm1=X[i+1][j-1];

        Xim1j=X[i-1][j];
        Xij=X[i][j];
        Xip1j=X[i+1][j];

        for(j = 0; j < n; j++)
        {

            Xim1jp1=X[i-1][j+1];
            Xijp1=X[i][j+1];
            Xip1jp1=X[i+1][j+1];

            YTemp = Xim1jm1 + Xim1j + Xim1jp1 + Xijm1 + Xij + Xijp1 +
                    Xip1jm1 + Xip1j + Xip1jp1 ;//Calculs

            Y[i][j] = YTemp;// store
            YTemp = 0;

            //Rotation, comme j augmente on prend la valeur a la colonne +1
            Xim1jm1 = Xim1j;
            Xijm1 = Xij;
            Xip1jm1 = Xip1j;

            Xim1j = Xim1jp1;
            Xij = Xijp1;
            Xip1j = Xip1jp1;

        }
        j=0;
    }
}


// -----------------------------------------------------
void sum3_f32matrix_red(float32 **X, float32 **Y, int n)
// -----------------------------------------------------
{
    int i = 0, j = 0;
    float32 YTemp = 0;
    float32 Xim1jm1, Xim1j, Xim1jp1;

    float32 Xijm1, Xij, Xijp1;

    float32 Xip1jm1, Xip1j, Xip1jp1;
    float rjm1, rj, rjp1;
    //Loads - prologue


    for(i = 0; i < n; i++)
    {
        Xim1jm1 = X[i-1][j-1];
        Xijm1=X[i][j-1];
        Xip1jm1=X[i+1][j-1];
        rjm1 = Xim1jm1 + Xijm1 + Xip1jm1;

        Xim1j=X[i-1][j];
        Xij=X[i][j];
        Xip1j=X[i+1][j];
        rj = Xim1j + Xij + Xip1j;

        for(j = 0; j < n; j++)
        {

            Xim1jp1=X[i-1][j+1];
            Xijp1=X[i][j+1];
            Xip1jp1=X[i+1][j+1];

            rjp1 = Xim1jp1 + Xijp1 + Xip1jp1;

            Y[i][j] = rjm1 + rj + rjp1;// store


            //Rotation, comme j augmente on prend la valeur a la colonne +1
            rjm1 = rj;
            rj = rjp1;
        }
        j=0;
    }
}



// ----------------------------------------------------
void sum3_f32matrix_lu(float32 **X, float32 **Y, int n)
// ----------------------------------------------------
{
    int i, j;
    int test = 0;
    float32 YTemp = 0;
    float32 Xim1jm1, Xim1j, Xim1jp1;

    float32 Xijm1, Xij, Xijp1;

    float32 Xip1jm1, Xip1j, Xip1jp1;

    for(i = 0; i < n; i++)
    {

        //Loads Avec j
        Xim1jm1 = X[i-1][j-1];
        Xim1j=X[i-1][j];

        Xijm1=X[i][j-1];
        Xij=X[i][j];

        Xip1jm1=X[i+1][j-1];
        Xip1j=X[i+1][j];

        for(j = 0; j < n-2; j+=3)
        {


            Xim1jp1=X[i-1][j+1];
            Xijp1=X[i][j+1];
            Xip1jp1=X[i+1][j+1];


            Y[i][j]  = Xim1jm1 + Xim1j + Xim1jp1 + Xijm1 + Xij + Xijp1 + Xip1jm1 + Xip1j + Xip1jp1 ;//Calculs


            //Les j-1 sont remplaces car plus necessaires par les (j+2)
            Xim1jm1 = X[i-1][j+2];
            Xijm1=X[i][j+2];
            Xip1jm1=X[i+1][j+2];

            Y[i][j+1]  =  Xijm1 + Xij + Xijp1 + Xip1jm1 + Xip1j + Xip1jp1 + Xim1jm1 + Xim1j + Xim1jp1 ;//Calculs


            //Les j sont remplaces car plus necessaires par les (j+3)
            Xim1j=X[i-1][j+3];
            Xij=X[i][j+3];
            Xip1j=X[i+1][j+3];

            Y[i][j+2]  =  Xip1jm1 + Xip1j + Xip1jp1 + Xim1jm1 + Xim1j + Xim1jp1 + Xijm1 + Xij + Xijp1 ;//Calculs

        }

        //Epilogue
        int m = n%3;
        
        switch(m)
        {
        case 2:
        {
            //Les j-1 sont remplaces car plus necessaires par les (j+2)
            Xim1jm1 = X[i-1][j+2];
            Xip1jm1=X[i+1][j+2];
            Xip1jm1=X[i+1][j+2];

            Y[i][j+1] =  Xijm1 + Xij + Xijp1 + Xip1jm1 + Xip1j + Xip1jp1 + Xim1jm1 + Xim1j + Xim1jp1 ;//Calculs

        }
        case 1:
        {

            Xim1jp1=X[i-1][j+1];
            Xijp1=X[i][j+1];
            Xip1jp1=X[i+1][j+1];


            Y[i][j] = Xim1jm1 + Xim1j + Xim1jp1 + Xijm1 + Xij + Xijp1 + Xip1jm1 + Xip1j + Xip1jp1 ;//Calculs

        }
        case 0:
            break;
        }
        
        j = 0;
    }
}

// ----------------------------------------------------------------------
void sum3x2_f32matrix_array(float32 **X, float32 **Y, float32 **Z, int n)
// ----------------------------------------------------------------------
{
    sum3_f32matrix_array(X, Y, n);
    sum3_f32matrix_array(Y, Z, n);

}
// --------------------------------------------------------------------
void sum3x2_f32matrix_red(float32 **X, float32 **Y, float32 **Z, int n)
// --------------------------------------------------------------------
{
    sum3_f32matrix_red(X, Y, n);
    sum3_f32matrix_red(Y, Z, n);

}
// ------------------------------------------------------------
void sum3_f32vector_reg(float32 **X, float32 **Y, int i, int n)
// ------------------------------------------------------------
{
    // avec scalarisation
    int j;
    float32 YTemp = 0;
    float32 Xim1jm1, Xim1j, Xim1jp1;

    float32 Xijm1, Xij, Xijp1;

    float32 Xip1jm1, Xip1j, Xip1jp1;


    for(j = 0; j < n; j++)
    {
        //Loads
        Xim1jm1 = X[i-1][j-1];
        Xim1j=X[i-1][j];
        Xim1jp1=X[i-1][j+1];

        Xijm1=X[i][j-1];
        Xij=X[i][j];
        Xijp1=X[i][j+1];

        Xip1jm1=X[i+1][j-1];
        Xip1j=X[i+1][j];
        Xip1jp1=X[i+1][j+1];


        YTemp = Xim1jm1 + Xim1j + Xim1jp1 + Xijm1 + Xij + Xijp1 +
                Xip1jm1 + Xip1j + Xip1jp1 ;//Calculs

        Y[i][j] = YTemp;// store
        YTemp = 0;
    }

}
// ----------------------------------------------------------------------------------------------------
void sum3x2_f32matrix_reg_pipe(float32** restrict X, float32** restrict Y, float32** restrict Z, int n)
// ----------------------------------------------------------------------------------------------------
{
    int i;
    sum3_f32vector_red(X, Y, 0, n);
    sum3_f32vector_red(X, Y, 1, n);
    //On a besoin de 3 lignes de Y pour faire une ligne correcte de Z
    for(i = 0; i < n-2; i++)
    {
        sum3_f32vector_red(X, Y, i+2, n);
        sum3_f32vector_red(Y, Z, i, n);
    }
    sum3_f32vector_red(Y, Z, n-2, n);
    sum3_f32vector_red(Y, Z, n-1, n);

    //Pour que ça prenne les dernieres lignes
}
// ------------------------------------------------------------------------------
void sum3_f32vector_red(float32** restrict X, float32** restrict Y, int i, int n)
// ------------------------------------------------------------------------------
{
    int j = 0;
    float32 YTemp = 0;
    float32 Xim1jm1, Xim1j, Xim1jp1;

    float32 Xijm1, Xij, Xijp1;

    float32 Xip1jm1, Xip1j, Xip1jp1;
    float rjm1, rj, rjp1;


    Xim1jm1 = X[i-1][j-1];
    Xijm1=X[i][j-1];
    Xip1jm1=X[i+1][j-1];
    rjm1 = Xim1jm1 + Xijm1 + Xip1jm1;

    Xim1j=X[i-1][j];
    Xij=X[i][j];
    Xip1j=X[i+1][j];
    rj = Xim1j + Xij + Xip1j;

    for(j = 0; j < n; j++)
    {

        Xim1jp1=X[i-1][j+1];
        Xijp1=X[i][j+1];
        Xip1jp1=X[i+1][j+1];

        rjp1 = Xim1jp1 + Xijp1 + Xip1jp1;


        Y[i][j] = rjm1 + rj + rjp1;// store


        //Rotation, comme j augmente on prend la valeur a la colonne +1
        rjm1 = rj;
        rj = rjp1;
    }
    j=0;
}
// ----------------------------------------------------------------------------------------------------
void sum3x2_f32matrix_red_pipe(float32** restrict X, float32** restrict Y, float32** restrict Z, int n)
// ----------------------------------------------------------------------------------------------------
{
    int i;
    sum3_f32vector_red(X, Y, 0, n);
    sum3_f32vector_red(X, Y, 1, n);
    //On a besoin de 3 lignes de Y pour faire une ligne correcte de Z
    for(i = 0; i < n-2; i++)
    {
        sum3_f32vector_red(X, Y, i+2, n);
        sum3_f32vector_red(Y, Z, i, n);
    }
    sum3_f32vector_red(Y, Z, n-2, n);
    sum3_f32vector_red(Y, Z, n-1, n);
    //Pour prendre les dernieres lignes
}
// -----------------------------------------------------------------------------------------------------------
void sum3x2_f32matrix_red_pipe_inline(float32** restrict X, float32** restrict Y, float32** restrict Z, int n)
// -----------------------------------------------------------------------------------------------------------
{
	
}
